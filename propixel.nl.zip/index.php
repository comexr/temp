<html lang="nl-NL" class=" no-touch">
   <head>
      <meta charset="UTF-8">
      <title>ProPixel – De alles in één oplossing voor uw websites</title>
      <meta name="robots" content="noindex, nofollow">
      <link rel="dns-prefetch" href="//fonts.googleapis.com">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="SKYPE_TOOLBAR" content="SKYPE_TOOLBAR_PARSER_COMPATIBLE">
      <meta property="og:title" content="ProPixel – De alles in één oplossing voor uw websites">
      <meta property="og:url" content="https://propixel.nl/">
      
      <meta property="og:locale" content="nl_NL">
      <meta property="og:site_name" content="ProPixel">
      <meta property="og:type" content="website">
      <meta property="og:image" content="/assets/media/scott-graham-5fNmWej4tAA-unsplash-1024x683.jpg" itemprop="image">
      
      <link rel="stylesheet" id="us-fonts-css" href="https://fonts.googleapis.com/css?family=Noto+Sans%3A400%2C700%7CLexend%3A400%2C700&amp;display=swap&amp;ver=6.4.3" media="all">
      <link rel="stylesheet" id="us-style-css" href="/assets/css/style.css?ver=8.21" media="all">
      <script></script>
      <link rel="canonical" href="https://propixel.nl/">
      <link rel="shortlink" href="https://propixel.nl/">
      <script id="us_add_no_touch">
         if ( ! /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test( navigator.userAgent ) ) {
         	var root = document.getElementsByTagName( 'html' )[ 0 ]
         	root.className += " no-touch";
         }
      </script>
      <link rel="icon" href="/assets/media/Icon-150x150.png" sizes="32x32">
      <link rel="icon" href="/assets/media/Icon.png" sizes="192x192">
      <link rel="apple-touch-icon" href="/assets/media/Icon.png">
      <meta name="msapplication-TileImage" content="/assets/media/Icon.png">
      <noscript>
         <style> .wpb_animate_when_almost_visible { opacity: 1; }</style>
      </noscript>
      <style>
         .m_layout_dropdown .w-nav-list .level_1 .hover_simple{
            left: -1rem;
            right: -1rem;
            padding-left: .3rem;
            padding-right: .3rem;
         }
         .l-subheader.at_middle .type_mobile .w-nav-list.level_1
         {
            background: var(--color-header-middle-bg);
            color: var(--color-header-middle-text);
         }
      </style>
      <style id="us-icon-fonts">@font-face{font-display:block;font-style:normal;font-family:"fontawesome";font-weight:900;src:url("/assets/fonts/fa-solid-900.woff2?ver=8.19") format("woff2"),url("/assets/fonts/fa-solid-900.woff?ver=8.19") format("woff")}.fas{font-family:"fontawesome";font-weight:900}@font-face{font-display:block;font-style:normal;font-family:"fontawesome";font-weight:400;src:url("/assets/fonts/fa-regular-400.woff2?ver=8.19") format("woff2"),url("/assets/fonts/fa-regular-400.woff?ver=8.19") format("woff")}.far{font-family:"fontawesome";font-weight:400}@font-face{font-display:block;font-style:normal;font-family:"fontawesome";font-weight:300;src:url("https://propixel.nl/wp-content/themes/Impreza/fonts/fa-light-300.woff2?ver=8.19") format("woff2"),url("https://propixel.nl/wp-content/themes/Impreza/fonts/fa-light-300.woff?ver=8.19") format("woff")}.fal{font-family:"fontawesome";font-weight:300}@font-face{font-display:block;font-style:normal;font-family:"Font Awesome 5 Duotone";font-weight:900;src:url("https://propixel.nl/wp-content/themes/Impreza/fonts/fa-duotone-900.woff2?ver=8.19") format("woff2"),url("https://propixel.nl/wp-content/themes/Impreza/fonts/fa-duotone-900.woff?ver=8.19") format("woff")}.fad{font-family:"Font Awesome 5 Duotone";font-weight:900}.fad{position:relative}.fad:before{position:absolute}.fad:after{opacity:0.4}@font-face{font-display:block;font-style:normal;font-family:"Font Awesome 5 Brands";font-weight:400;src:url("/assets/fonts/fa-brands-400.woff2?ver=8.19") format("woff2"),url("/assets/fonts/fa-brands-400.woff?ver=8.19") format("woff")}.fab{font-family:"Font Awesome 5 Brands";font-weight:400}@font-face{font-display:block;font-style:normal;font-family:"Material Icons";font-weight:400;src:url("/assets/fonts/material-icons.woff2?ver=8.19") format("woff2"),url("/assets/fonts/material-icons.woff?ver=8.19") format("woff")}.material-icons{font-family:"Material Icons";font-weight:400}</style>
      <style id="us-theme-options-css">:root{--color-header-middle-bg:#fff;--color-header-middle-bg-grad:#fff;--color-header-middle-text:#000056;--color-header-middle-text-hover:#00f0f1;--color-header-transparent-bg:transparent;--color-header-transparent-bg-grad:transparent;--color-header-transparent-text:#fff;--color-header-transparent-text-hover:#fff;--color-chrome-toolbar:#f2f4f7;--color-chrome-toolbar-grad:#f2f4f7;--color-header-top-bg:#f2f4f7;--color-header-top-bg-grad:#f2f4f7;--color-header-top-text:#727f9f;--color-header-top-text-hover:#00f0f1;--color-header-top-transparent-bg:rgba(0,0,0,0.2);--color-header-top-transparent-bg-grad:rgba(0,0,0,0.2);--color-header-top-transparent-text:rgba(255,255,255,0.66);--color-header-top-transparent-text-hover:#fff;--color-content-bg:#fff;--color-content-bg-grad:#fff;--color-content-bg-alt:#f2f4f7;--color-content-bg-alt-grad:#f2f4f7;--color-content-border:#e3e7f0;--color-content-heading:#0f131f;--color-content-heading-grad:#0f131f;--color-content-text:#000056;--color-content-link:#00f0f1;--color-content-link-hover:#000056;--color-content-primary:#00f0f1;--color-content-primary-grad:#00f0f1;--color-content-secondary:#000056;--color-content-secondary-grad:#000056;--color-content-faded:#727f9f;--color-content-overlay:rgba(15,19,31,0.80);--color-content-overlay-grad:rgba(15,19,31,0.80);--color-alt-content-bg:#f2f4f7;--color-alt-content-bg-grad:#f2f4f7;--color-alt-content-bg-alt:#fff;--color-alt-content-bg-alt-grad:#fff;--color-alt-content-border:#e3e7f0;--color-alt-content-heading:#0f131f;--color-alt-content-heading-grad:#0f131f;--color-alt-content-text:#000056;--color-alt-content-link:#00f0f1;--color-alt-content-link-hover:#000056;--color-alt-content-primary:#00f0f1;--color-alt-content-primary-grad:#00f0f1;--color-alt-content-secondary:#000056;--color-alt-content-secondary-grad:#000056;--color-alt-content-faded:#727f9f;--color-alt-content-overlay:rgba(100,108,253,0.85);--color-alt-content-overlay-grad:rgba(100,108,253,0.85);--color-footer-bg:#0f131f;--color-footer-bg-grad:#0f131f;--color-footer-bg-alt:#1c2130;--color-footer-bg-alt-grad:#1c2130;--color-footer-border:#2b3242;--color-footer-heading:#fff;--color-footer-heading-grad:#fff;--color-footer-text:#8d9096;--color-footer-link:#00f0f1;--color-footer-link-hover:#fff;--color-subfooter-bg:#000056;--color-subfooter-bg-grad:#000056;--color-subfooter-bg-alt:#2b3242;--color-subfooter-bg-alt-grad:#2b3242;--color-subfooter-border:#727f9f;--color-subfooter-heading:#e3e7f0;--color-subfooter-heading-grad:#e3e7f0;--color-subfooter-text:#9ba5bf;--color-subfooter-link:#e3e7f0;--color-subfooter-link-hover:#fff;--color-content-primary-faded:rgba(0,240,241,0.15);--box-shadow:0 5px 15px rgba(0,0,0,.15);--box-shadow-up:0 -5px 15px rgba(0,0,0,.15);--site-canvas-width:1300px;--site-content-width:1140px;--text-block-margin-bottom:0rem;--inputs-font-size:1rem;--inputs-height:2.8rem;--inputs-padding:0.8rem;--inputs-border-width:0px;--inputs-text-color:var(--color-content-text)}:root{--font-family:"Noto Sans";--font-size:18px;--line-height:30px;--font-weight:400;--bold-font-weight:700;--text-transform:none;--font-style:normal;--letter-spacing:0em;--h1-font-family:Lexend,sans-serif;--h1-font-size:calc(32px + 2vw);--h1-line-height:1.2;--h1-font-weight:400;--h1-bold-font-weight:700;--h1-text-transform:none;--h1-font-style:normal;--h1-letter-spacing:0em;--h1-margin-bottom:1.5rem;--h2-font-family:var(--h1-font-family);--h2-font-size:calc(22px + 1.3vw);--h2-line-height:1.2;--h2-font-weight:var(--h1-font-weight);--h2-bold-font-weight:var(--h1-bold-font-weight);--h2-text-transform:var(--h1-text-transform);--h2-font-style:var(--h1-font-style);--h2-letter-spacing:0em;--h2-margin-bottom:1.5rem;--h3-font-family:var(--h1-font-family);--h3-font-size:calc(19px + 1vw);--h3-line-height:1.2;--h3-font-weight:var(--h1-font-weight);--h3-bold-font-weight:var(--h1-bold-font-weight);--h3-text-transform:var(--h1-text-transform);--h3-font-style:var(--h1-font-style);--h3-letter-spacing:0em;--h3-margin-bottom:1.5rem;--h4-font-family:var(--h1-font-family);--h4-font-size:calc(17px + 0.9vw);--h4-line-height:1.2;--h4-font-weight:var(--h1-font-weight);--h4-bold-font-weight:var(--h1-bold-font-weight);--h4-text-transform:var(--h1-text-transform);--h4-font-style:var(--h1-font-style);--h4-letter-spacing:0em;--h4-margin-bottom:1.5rem;--h5-font-family:var(--h1-font-family);--h5-font-size:calc(16px + 0.8vw);--h5-line-height:1.2;--h5-font-weight:var(--h1-font-weight);--h5-bold-font-weight:var(--h1-bold-font-weight);--h5-text-transform:var(--h1-text-transform);--h5-font-style:var(--h1-font-style);--h5-letter-spacing:0em;--h5-margin-bottom:1.5rem;--h6-font-family:var(--h1-font-family);--h6-font-size:calc(15px + 0.8vw);--h6-line-height:1.2;--h6-font-weight:var(--h1-font-weight);--h6-bold-font-weight:var(--h1-bold-font-weight);--h6-text-transform:var(--h1-text-transform);--h6-font-style:var(--h1-font-style);--h6-letter-spacing:0em;--h6-margin-bottom:1.5rem}h1{font-family:var(--h1-font-family,inherit);font-weight:var(--h1-font-weight,inherit);font-size:var(--h1-font-size,inherit);font-style:var(--h1-font-style,inherit);line-height:var(--h1-line-height,1.4);letter-spacing:var(--h1-letter-spacing,inherit);text-transform:var(--h1-text-transform,inherit);margin-bottom:var(--h1-margin-bottom,1.5rem)}h1>strong{font-weight:var(--h1-bold-font-weight,bold)}h2{font-family:var(--h2-font-family,inherit);font-weight:var(--h2-font-weight,inherit);font-size:var(--h2-font-size,inherit);font-style:var(--h2-font-style,inherit);line-height:var(--h2-line-height,1.4);letter-spacing:var(--h2-letter-spacing,inherit);text-transform:var(--h2-text-transform,inherit);margin-bottom:var(--h2-margin-bottom,1.5rem)}h2>strong{font-weight:var(--h2-bold-font-weight,bold)}h3{font-family:var(--h3-font-family,inherit);font-weight:var(--h3-font-weight,inherit);font-size:var(--h3-font-size,inherit);font-style:var(--h3-font-style,inherit);line-height:var(--h3-line-height,1.4);letter-spacing:var(--h3-letter-spacing,inherit);text-transform:var(--h3-text-transform,inherit);margin-bottom:var(--h3-margin-bottom,1.5rem)}h3>strong{font-weight:var(--h3-bold-font-weight,bold)}h4{font-family:var(--h4-font-family,inherit);font-weight:var(--h4-font-weight,inherit);font-size:var(--h4-font-size,inherit);font-style:var(--h4-font-style,inherit);line-height:var(--h4-line-height,1.4);letter-spacing:var(--h4-letter-spacing,inherit);text-transform:var(--h4-text-transform,inherit);margin-bottom:var(--h4-margin-bottom,1.5rem)}h4>strong{font-weight:var(--h4-bold-font-weight,bold)}h5{font-family:var(--h5-font-family,inherit);font-weight:var(--h5-font-weight,inherit);font-size:var(--h5-font-size,inherit);font-style:var(--h5-font-style,inherit);line-height:var(--h5-line-height,1.4);letter-spacing:var(--h5-letter-spacing,inherit);text-transform:var(--h5-text-transform,inherit);margin-bottom:var(--h5-margin-bottom,1.5rem)}h5>strong{font-weight:var(--h5-bold-font-weight,bold)}h6{font-family:var(--h6-font-family,inherit);font-weight:var(--h6-font-weight,inherit);font-size:var(--h6-font-size,inherit);font-style:var(--h6-font-style,inherit);line-height:var(--h6-line-height,1.4);letter-spacing:var(--h6-letter-spacing,inherit);text-transform:var(--h6-text-transform,inherit);margin-bottom:var(--h6-margin-bottom,1.5rem)}h6>strong{font-weight:var(--h6-bold-font-weight,bold)}body{background:var(--color-content-bg-alt)}@media (max-width:1230px){.l-main .aligncenter{max-width:calc(100vw - 5rem)}}@media (min-width:1381px){body.usb_preview .hide_on_default{opacity:0.25!important}.vc_hidden-lg,body:not(.usb_preview) .hide_on_default{display:none!important}.default_align_left{text-align:left;justify-content:flex-start}.default_align_right{text-align:right;justify-content:flex-end}.default_align_center{text-align:center;justify-content:center}.default_align_justify{justify-content:space-between}.w-hwrapper>.default_align_justify,.default_align_justify>.w-btn{width:100%}}@media (min-width:1025px) and (max-width:1380px){body.usb_preview .hide_on_laptops{opacity:0.25!important}.vc_hidden-md,body:not(.usb_preview) .hide_on_laptops{display:none!important}.laptops_align_left{text-align:left;justify-content:flex-start}.laptops_align_right{text-align:right;justify-content:flex-end}.laptops_align_center{text-align:center;justify-content:center}.laptops_align_justify{justify-content:space-between}.w-hwrapper>.laptops_align_justify,.laptops_align_justify>.w-btn{width:100%}.g-cols.via_grid[style*="--laptops-gap"]{grid-gap:var(--laptops-gap,3rem)}}@media (min-width:601px) and (max-width:1024px){body.usb_preview .hide_on_tablets{opacity:0.25!important}.vc_hidden-sm,body:not(.usb_preview) .hide_on_tablets{display:none!important}.tablets_align_left{text-align:left;justify-content:flex-start}.tablets_align_right{text-align:right;justify-content:flex-end}.tablets_align_center{text-align:center;justify-content:center}.tablets_align_justify{justify-content:space-between}.w-hwrapper>.tablets_align_justify,.tablets_align_justify>.w-btn{width:100%}.g-cols.via_grid[style*="--tablets-gap"]{grid-gap:var(--tablets-gap,3rem)}}@media (max-width:600px){body.usb_preview .hide_on_mobiles{opacity:0.25!important}.vc_hidden-xs,body:not(.usb_preview) .hide_on_mobiles{display:none!important}.mobiles_align_left{text-align:left;justify-content:flex-start}.mobiles_align_right{text-align:right;justify-content:flex-end}.mobiles_align_center{text-align:center;justify-content:center}.mobiles_align_justify{justify-content:space-between}.w-hwrapper>.mobiles_align_justify,.mobiles_align_justify>.w-btn{width:100%}.w-hwrapper.stack_on_mobiles{display:block}.w-hwrapper.stack_on_mobiles>*{display:block;margin:0 0 var(--hwrapper-gap,1.2rem)}.w-hwrapper.stack_on_mobiles>:last-child{margin-bottom:0}.g-cols.via_grid[style*="--mobiles-gap"]{grid-gap:var(--mobiles-gap,1.5rem)}}@media (max-width:1380px){.g-cols.laptops-cols_1{grid-template-columns:100%}.g-cols.laptops-cols_1.reversed>div:last-of-type{order:-1}.g-cols.laptops-cols_2{grid-template-columns:repeat(2,1fr)}.g-cols.laptops-cols_3{grid-template-columns:repeat(3,1fr)}.g-cols.laptops-cols_4{grid-template-columns:repeat(4,1fr)}.g-cols.laptops-cols_5{grid-template-columns:repeat(5,1fr)}.g-cols.laptops-cols_6{grid-template-columns:repeat(6,1fr)}.g-cols.laptops-cols_1-2{grid-template-columns:1fr 2fr}.g-cols.laptops-cols_2-1{grid-template-columns:2fr 1fr}.g-cols.laptops-cols_2-3{grid-template-columns:2fr 3fr}.g-cols.laptops-cols_3-2{grid-template-columns:3fr 2fr}.g-cols.laptops-cols_1-3{grid-template-columns:1fr 3fr}.g-cols.laptops-cols_3-1{grid-template-columns:3fr 1fr}.g-cols.laptops-cols_1-4{grid-template-columns:1fr 4fr}.g-cols.laptops-cols_4-1{grid-template-columns:4fr 1fr}.g-cols.laptops-cols_1-5{grid-template-columns:1fr 5fr}.g-cols.laptops-cols_5-1{grid-template-columns:5fr 1fr}.g-cols.laptops-cols_1-2-1{grid-template-columns:1fr 2fr 1fr}.g-cols.laptops-cols_1-3-1{grid-template-columns:1fr 3fr 1fr}.g-cols.laptops-cols_1-4-1{grid-template-columns:1fr 4fr 1fr}}@media (max-width:1024px){.g-cols.tablets-cols_1{grid-template-columns:100%}.g-cols.tablets-cols_1.reversed>div:last-of-type{order:-1}.g-cols.tablets-cols_2{grid-template-columns:repeat(2,1fr)}.g-cols.tablets-cols_3{grid-template-columns:repeat(3,1fr)}.g-cols.tablets-cols_4{grid-template-columns:repeat(4,1fr)}.g-cols.tablets-cols_5{grid-template-columns:repeat(5,1fr)}.g-cols.tablets-cols_6{grid-template-columns:repeat(6,1fr)}.g-cols.tablets-cols_1-2{grid-template-columns:1fr 2fr}.g-cols.tablets-cols_2-1{grid-template-columns:2fr 1fr}.g-cols.tablets-cols_2-3{grid-template-columns:2fr 3fr}.g-cols.tablets-cols_3-2{grid-template-columns:3fr 2fr}.g-cols.tablets-cols_1-3{grid-template-columns:1fr 3fr}.g-cols.tablets-cols_3-1{grid-template-columns:3fr 1fr}.g-cols.tablets-cols_1-4{grid-template-columns:1fr 4fr}.g-cols.tablets-cols_4-1{grid-template-columns:4fr 1fr}.g-cols.tablets-cols_1-5{grid-template-columns:1fr 5fr}.g-cols.tablets-cols_5-1{grid-template-columns:5fr 1fr}.g-cols.tablets-cols_1-2-1{grid-template-columns:1fr 2fr 1fr}.g-cols.tablets-cols_1-3-1{grid-template-columns:1fr 3fr 1fr}.g-cols.tablets-cols_1-4-1{grid-template-columns:1fr 4fr 1fr}}@media (max-width:600px){.g-cols.mobiles-cols_1{grid-template-columns:100%}.g-cols.mobiles-cols_1.reversed>div:last-of-type{order:-1}.g-cols.mobiles-cols_2{grid-template-columns:repeat(2,1fr)}.g-cols.mobiles-cols_3{grid-template-columns:repeat(3,1fr)}.g-cols.mobiles-cols_4{grid-template-columns:repeat(4,1fr)}.g-cols.mobiles-cols_5{grid-template-columns:repeat(5,1fr)}.g-cols.mobiles-cols_6{grid-template-columns:repeat(6,1fr)}.g-cols.mobiles-cols_1-2{grid-template-columns:1fr 2fr}.g-cols.mobiles-cols_2-1{grid-template-columns:2fr 1fr}.g-cols.mobiles-cols_2-3{grid-template-columns:2fr 3fr}.g-cols.mobiles-cols_3-2{grid-template-columns:3fr 2fr}.g-cols.mobiles-cols_1-3{grid-template-columns:1fr 3fr}.g-cols.mobiles-cols_3-1{grid-template-columns:3fr 1fr}.g-cols.mobiles-cols_1-4{grid-template-columns:1fr 4fr}.g-cols.mobiles-cols_4-1{grid-template-columns:4fr 1fr}.g-cols.mobiles-cols_1-5{grid-template-columns:1fr 5fr}.g-cols.mobiles-cols_5-1{grid-template-columns:5fr 1fr}.g-cols.mobiles-cols_1-2-1{grid-template-columns:1fr 2fr 1fr}.g-cols.mobiles-cols_1-3-1{grid-template-columns:1fr 3fr 1fr}.g-cols.mobiles-cols_1-4-1{grid-template-columns:1fr 4fr 1fr}.g-cols:not([style*="--gap"]){grid-gap:1.5rem}}@media (max-width:599px){.l-canvas{overflow:hidden}.g-cols.stacking_default.reversed>div:last-of-type{order:-1}.g-cols.stacking_default.via_flex>div:not([class*="vc_col-xs"]){width:100%;margin:0 0 1.5rem}.g-cols.stacking_default.via_grid.mobiles-cols_1{grid-template-columns:100%}.g-cols.stacking_default.via_flex.type_boxes>div,.g-cols.stacking_default.via_flex.reversed>div:first-child,.g-cols.stacking_default.via_flex:not(.reversed)>div:last-child,.g-cols.stacking_default.via_flex>div.has_bg_color{margin-bottom:0}.g-cols.stacking_default.via_flex.type_default>.wpb_column.stretched{margin-left:-1rem;margin-right:-1rem}.g-cols.stacking_default.via_grid.mobiles-cols_1>.wpb_column.stretched,.g-cols.stacking_default.via_flex.type_boxes>.wpb_column.stretched{margin-left:-2.5rem;margin-right:-2.5rem;width:auto}.vc_column-inner.type_sticky>.wpb_wrapper,.vc_column_container.type_sticky>.vc_column-inner{top:0!important}}@media (min-width:600px){body:not(.rtl) .l-section.for_sidebar.at_left>div>.l-sidebar,.rtl .l-section.for_sidebar.at_right>div>.l-sidebar{order:-1}.vc_column_container.type_sticky>.vc_column-inner,.vc_column-inner.type_sticky>.wpb_wrapper{position:-webkit-sticky;position:sticky}.l-section.type_sticky{position:-webkit-sticky;position:sticky;top:0;z-index:11;transform:translateZ(0); transition:top 0.3s cubic-bezier(.78,.13,.15,.86) 0.1s}.header_hor .l-header.post_fixed.sticky_auto_hide{z-index:12}.admin-bar .l-section.type_sticky{top:32px}.l-section.type_sticky>.l-section-h{transition:padding-top 0.3s}.header_hor .l-header.pos_fixed:not(.down)~.l-main .l-section.type_sticky:not(:first-of-type){top:var(--header-sticky-height)}.admin-bar.header_hor .l-header.pos_fixed:not(.down)~.l-main .l-section.type_sticky:not(:first-of-type){top:calc( var(--header-sticky-height) + 32px )}.header_hor .l-header.pos_fixed.sticky:not(.down)~.l-main .l-section.type_sticky:first-of-type>.l-section-h{padding-top:var(--header-sticky-height)}.header_hor.headerinpos_bottom .l-header.pos_fixed.sticky:not(.down)~.l-main .l-section.type_sticky:first-of-type>.l-section-h{padding-bottom:var(--header-sticky-height)!important}}@media screen and (min-width:1230px){.g-cols.via_flex.type_default>.wpb_column.stretched:first-of-type{margin-left:calc( var(--site-content-width) / 2 + 0px / 2 + 1.5rem - 50vw)}.g-cols.via_flex.type_default>.wpb_column.stretched:last-of-type{margin-right:calc( var(--site-content-width) / 2 + 0px / 2 + 1.5rem - 50vw)}.l-main .alignfull, .w-separator.width_screen,.g-cols.via_grid>.wpb_column.stretched:first-of-type,.g-cols.via_flex.type_boxes>.wpb_column.stretched:first-of-type{margin-left:calc( var(--site-content-width) / 2 + 0px / 2 - 50vw )}.l-main .alignfull, .w-separator.width_screen,.g-cols.via_grid>.wpb_column.stretched:last-of-type,.g-cols.via_flex.type_boxes>.wpb_column.stretched:last-of-type{margin-right:calc( var(--site-content-width) / 2 + 0px / 2 - 50vw )}}@media (max-width:600px){.w-form-row.for_submit[style*=btn-size-mobiles] .w-btn{font-size:var(--btn-size-mobiles)!important}}a,button,input[type=submit],.ui-slider-handle{outline:none!important}.w-toplink,.w-header-show{background:rgba(0,0,0,0.3)}.no-touch .w-toplink.active:hover,.no-touch .w-header-show:hover{background:var(--color-content-primary-grad)}button[type=submit]:not(.w-btn),input[type=submit]:not(.w-btn),.us-nav-style_1>*,.navstyle_1>.owl-nav button,.us-btn-style_1{font-size:16px;line-height:1.2!important;font-weight:700;font-style:normal;text-transform:none;letter-spacing:0em;border-radius:0.3em;padding:1.0em 2.0em;background:var(--color-content-secondary);border-color:transparent;color:#ffffff!important}button[type=submit]:not(.w-btn):before,input[type=submit]:not(.w-btn),.us-nav-style_1>*:before,.navstyle_1>.owl-nav button:before,.us-btn-style_1:before{border-width:0px}.no-touch button[type=submit]:not(.w-btn):hover,.no-touch input[type=submit]:not(.w-btn):hover,.us-nav-style_1>span.current,.no-touch .us-nav-style_1>a:hover,.no-touch .navstyle_1>.owl-nav button:hover,.no-touch .us-btn-style_1:hover{background:var(--color-content-primary);border-color:transparent;color:#ffffff!important}.us-nav-style_1>*{min-width:calc(1.2em + 2 * 1.0em)}.us-nav-style_2>*,.navstyle_2>.owl-nav button,.us-btn-style_2{font-size:16px;line-height:1.2!important;font-weight:700;font-style:normal;text-transform:none;letter-spacing:0em;border-radius:0.3em;padding:1.0em 2.0em;background:var(--color-content-border);border-color:transparent;color:var(--color-content-text)!important}.us-nav-style_2>*:before,.navstyle_2>.owl-nav button:before,.us-btn-style_2:before{border-width:0px}.us-nav-style_2>span.current,.no-touch .us-nav-style_2>a:hover,.no-touch .navstyle_2>.owl-nav button:hover,.no-touch .us-btn-style_2:hover{background:var(--color-content-text);border-color:transparent;color:var(--color-content-bg)!important}.us-nav-style_2>*{min-width:calc(1.2em + 2 * 1.0em)}.w-filter.state_desktop.style_drop_default .w-filter-item-title,.select2-selection,select,textarea,input:not([type=submit]){font-weight:400;letter-spacing:0em;border-radius:0.3rem;background:var(--color-content-bg-alt);border-color:var(--color-content-border);color:var(--color-content-text);box-shadow:0px 1px 0px 0px rgba(0,0,0,0.08) inset}.w-filter.state_desktop.style_drop_default .w-filter-item-title:focus,.select2-container--open .select2-selection,select:focus,textarea:focus,input:not([type=submit]):focus{box-shadow:0px 0px 0px 2px var(--color-content-primary)}.w-form-row.move_label .w-form-row-label{font-size:1rem;top:calc(2.8rem/2 + 0px - 0.7em);margin:0 0.8rem;background-color:var(--color-content-bg-alt);color:var(--color-content-text)}.w-form-row.with_icon.move_label .w-form-row-label{margin-left:calc(1.6em + 0.8rem)}.color_alternate input:not([type=submit]),.color_alternate textarea,.color_alternate select,.color_alternate .move_label .w-form-row-label{background:var(--color-alt-content-bg-alt-grad)}.color_footer-top input:not([type=submit]),.color_footer-top textarea,.color_footer-top select,.color_footer-top .w-form-row.move_label .w-form-row-label{background:var(--color-subfooter-bg-alt-grad)}.color_footer-bottom input:not([type=submit]),.color_footer-bottom textarea,.color_footer-bottom select,.color_footer-bottom .w-form-row.move_label .w-form-row-label{background:var(--color-footer-bg-alt-grad)}.color_alternate input:not([type=submit]),.color_alternate textarea,.color_alternate select{border-color:var(--color-alt-content-border)}.color_footer-top input:not([type=submit]),.color_footer-top textarea,.color_footer-top select{border-color:var(--color-subfooter-border)}.color_footer-bottom input:not([type=submit]),.color_footer-bottom textarea,.color_footer-bottom select{border-color:var(--color-footer-border)}.color_alternate input:not([type=submit]),.color_alternate textarea,.color_alternate select,.color_alternate .w-form-row-field>i,.color_alternate .w-form-row-field:after,.color_alternate .widget_search form:after,.color_footer-top input:not([type=submit]),.color_footer-top textarea,.color_footer-top select,.color_footer-top .w-form-row-field>i,.color_footer-top .w-form-row-field:after,.color_footer-top .widget_search form:after,.color_footer-bottom input:not([type=submit]),.color_footer-bottom textarea,.color_footer-bottom select,.color_footer-bottom .w-form-row-field>i,.color_footer-bottom .w-form-row-field:after,.color_footer-bottom .widget_search form:after{color:inherit}.leaflet-default-icon-path{background-image:url(https://propixel.nl/wp-content/themes/Impreza/common/css/vendor/images/marker-icon.png)}</style>
      <style id="us-current-header-css"> .l-subheader.at_middle,.l-subheader.at_middle .w-dropdown-list,.l-subheader.at_middle .type_mobile .w-nav-list.level_1{background:var(--color-header-middle-bg);color:var(--color-header-middle-text)}.no-touch .l-subheader.at_middle a:hover,.no-touch .l-header.bg_transparent .l-subheader.at_middle .w-dropdown.opened a:hover{color:var(--color-header-middle-text-hover)}.l-header.bg_transparent:not(.sticky) .l-subheader.at_middle{background:var(--color-header-transparent-bg);color:var(--color-header-middle-text)}.no-touch .l-header.bg_transparent:not(.sticky) .at_middle .w-cart-link:hover,.no-touch .l-header.bg_transparent:not(.sticky) .at_middle .w-text a:hover,.no-touch .l-header.bg_transparent:not(.sticky) .at_middle .w-html a:hover,.no-touch .l-header.bg_transparent:not(.sticky) .at_middle .w-nav>a:hover,.no-touch .l-header.bg_transparent:not(.sticky) .at_middle .w-menu a:hover,.no-touch .l-header.bg_transparent:not(.sticky) .at_middle .w-search>a:hover,.no-touch .l-header.bg_transparent:not(.sticky) .at_middle .w-dropdown a:hover,.no-touch .l-header.bg_transparent:not(.sticky) .at_middle .type_desktop .menu-item.level_1:hover>a{color:var(--color-header-middle-text-hover)}.header_ver .l-header{background:var(--color-header-middle-bg);color:var(--color-header-middle-text)}@media (min-width:1381px){.hidden_for_default{display:none!important}.l-subheader.at_top{display:none}.l-subheader.at_bottom{display:none}.l-header{position:relative;z-index:111;width:100%}.l-subheader{margin:0 auto}.l-subheader.width_full{padding-left:1.5rem;padding-right:1.5rem}.l-subheader-h{display:flex;align-items:center;position:relative;margin:0 auto;max-width:var(--site-content-width,1200px);height:inherit}.w-header-show{display:none}.l-header.pos_fixed{position:fixed;left:0}.l-header.pos_fixed:not(.notransition) .l-subheader{transition-property:transform,background,box-shadow,line-height,height;transition-duration:.3s;transition-timing-function:cubic-bezier(.78,.13,.15,.86)}.headerinpos_bottom.sticky_first_section .l-header.pos_fixed{position:fixed!important}.header_hor .l-header.sticky_auto_hide{transition:transform .3s cubic-bezier(.78,.13,.15,.86) .1s}.header_hor .l-header.sticky_auto_hide.down{transform:translateY(-110%)}.l-header.bg_transparent:not(.sticky) .l-subheader{box-shadow:none!important;background:none}.l-header.bg_transparent~.l-main .l-section.width_full.height_auto:first-of-type>.l-section-h{padding-top:0!important;padding-bottom:0!important}.l-header.pos_static.bg_transparent{position:absolute;left:0}.l-subheader.width_full .l-subheader-h{max-width:none!important}.l-header.shadow_thin .l-subheader.at_middle,.l-header.shadow_thin .l-subheader.at_bottom{box-shadow:0 1px 0 rgba(0,0,0,0.08)}.l-header.shadow_wide .l-subheader.at_middle,.l-header.shadow_wide .l-subheader.at_bottom{box-shadow:0 3px 5px -1px rgba(0,0,0,0.1),0 2px 1px -1px rgba(0,0,0,0.05)}.header_hor .l-subheader-cell>.w-cart{margin-left:0;margin-right:0}:root{--header-height:100px;--header-sticky-height:80px}.l-header:before{content:'100'}.l-header.sticky:before{content:'80'}.l-subheader.at_top{line-height:40px;height:40px}.l-header.sticky .l-subheader.at_top{line-height:40px;height:40px}.l-subheader.at_middle{line-height:100px;height:100px}.l-header.sticky .l-subheader.at_middle{line-height:80px;height:80px}.l-subheader.at_bottom{line-height:50px;height:50px}.l-header.sticky .l-subheader.at_bottom{line-height:50px;height:50px}.headerinpos_above .l-header.pos_fixed{overflow:hidden;transition:transform 0.3s;transform:translate3d(0,-100%,0)}.headerinpos_above .l-header.pos_fixed.sticky{overflow:visible;transform:none}.headerinpos_above .l-header.pos_fixed~.l-section>.l-section-h,.headerinpos_above .l-header.pos_fixed~.l-main .l-section:first-of-type>.l-section-h{padding-top:0!important}.headerinpos_below .l-header.pos_fixed:not(.sticky){position:absolute;top:100%}.headerinpos_below .l-header.pos_fixed~.l-main>.l-section:first-of-type>.l-section-h{padding-top:0!important}.headerinpos_below .l-header.pos_fixed~.l-main .l-section.full_height:nth-of-type(2){min-height:100vh}.headerinpos_below .l-header.pos_fixed~.l-main>.l-section:nth-of-type(2)>.l-section-h{padding-top:var(--header-height)}.headerinpos_bottom .l-header.pos_fixed:not(.sticky){position:absolute;top:100vh}.headerinpos_bottom .l-header.pos_fixed~.l-main>.l-section:first-of-type>.l-section-h{padding-top:0!important}.headerinpos_bottom .l-header.pos_fixed~.l-main>.l-section:first-of-type>.l-section-h{padding-bottom:var(--header-height)}.headerinpos_bottom .l-header.pos_fixed.bg_transparent~.l-main .l-section.valign_center:not(.height_auto):first-of-type>.l-section-h{top:calc( var(--header-height) / 2 )}.headerinpos_bottom .l-header.pos_fixed:not(.sticky) .w-cart-dropdown,.headerinpos_bottom .l-header.pos_fixed:not(.sticky) .w-nav.type_desktop .w-nav-list.level_2{bottom:100%;transform-origin:0 100%}.headerinpos_bottom .l-header.pos_fixed:not(.sticky) .w-nav.type_mobile.m_layout_dropdown .w-nav-list.level_1{top:auto;bottom:100%;box-shadow:var(--box-shadow-up)}.headerinpos_bottom .l-header.pos_fixed:not(.sticky) .w-nav.type_desktop .w-nav-list.level_3,.headerinpos_bottom .l-header.pos_fixed:not(.sticky) .w-nav.type_desktop .w-nav-list.level_4{top:auto;bottom:0;transform-origin:0 100%}.headerinpos_bottom .l-header.pos_fixed:not(.sticky) .w-dropdown-list{top:auto;bottom:-0.4em;padding-top:0.4em;padding-bottom:2.4em}.admin-bar .l-header.pos_static.bg_solid~.l-main .l-section.full_height:first-of-type{min-height:calc( 100vh - var(--header-height) - 32px )}.admin-bar .l-header.pos_fixed:not(.sticky_auto_hide)~.l-main .l-section.full_height:not(:first-of-type){min-height:calc( 100vh - var(--header-sticky-height) - 32px )}.admin-bar.headerinpos_below .l-header.pos_fixed~.l-main .l-section.full_height:nth-of-type(2){min-height:calc(100vh - 32px)}}@media (min-width:1025px) and (max-width:1380px){.hidden_for_laptops{display:none!important}.l-subheader.at_top{display:none}.l-subheader.at_bottom{display:none}.l-header{position:relative;z-index:111;width:100%}.l-subheader{margin:0 auto}.l-subheader.width_full{padding-left:1.5rem;padding-right:1.5rem}.l-subheader-h{display:flex;align-items:center;position:relative;margin:0 auto;max-width:var(--site-content-width,1200px);height:inherit}.w-header-show{display:none}.l-header.pos_fixed{position:fixed;left:0}.l-header.pos_fixed:not(.notransition) .l-subheader{transition-property:transform,background,box-shadow,line-height,height;transition-duration:.3s;transition-timing-function:cubic-bezier(.78,.13,.15,.86)}.headerinpos_bottom.sticky_first_section .l-header.pos_fixed{position:fixed!important}.header_hor .l-header.sticky_auto_hide{transition:transform .3s cubic-bezier(.78,.13,.15,.86) .1s}.header_hor .l-header.sticky_auto_hide.down{transform:translateY(-110%)}.l-header.bg_transparent:not(.sticky) .l-subheader{box-shadow:none!important;background:none}.l-header.bg_transparent~.l-main .l-section.width_full.height_auto:first-of-type>.l-section-h{padding-top:0!important;padding-bottom:0!important}.l-header.pos_static.bg_transparent{position:absolute;left:0}.l-subheader.width_full .l-subheader-h{max-width:none!important}.l-header.shadow_thin .l-subheader.at_middle,.l-header.shadow_thin .l-subheader.at_bottom{box-shadow:0 1px 0 rgba(0,0,0,0.08)}.l-header.shadow_wide .l-subheader.at_middle,.l-header.shadow_wide .l-subheader.at_bottom{box-shadow:0 3px 5px -1px rgba(0,0,0,0.1),0 2px 1px -1px rgba(0,0,0,0.05)}.header_hor .l-subheader-cell>.w-cart{margin-left:0;margin-right:0}:root{--header-height:100px;--header-sticky-height:80px}.l-header:before{content:'100'}.l-header.sticky:before{content:'80'}.l-subheader.at_top{line-height:40px;height:40px}.l-header.sticky .l-subheader.at_top{line-height:40px;height:40px}.l-subheader.at_middle{line-height:100px;height:100px}.l-header.sticky .l-subheader.at_middle{line-height:80px;height:80px}.l-subheader.at_bottom{line-height:50px;height:50px}.l-header.sticky .l-subheader.at_bottom{line-height:50px;height:50px}.headerinpos_above .l-header.pos_fixed{overflow:hidden;transition:transform 0.3s;transform:translate3d(0,-100%,0)}.headerinpos_above .l-header.pos_fixed.sticky{overflow:visible;transform:none}.headerinpos_above .l-header.pos_fixed~.l-section>.l-section-h,.headerinpos_above .l-header.pos_fixed~.l-main .l-section:first-of-type>.l-section-h{padding-top:0!important}.headerinpos_below .l-header.pos_fixed:not(.sticky){position:absolute;top:100%}.headerinpos_below .l-header.pos_fixed~.l-main>.l-section:first-of-type>.l-section-h{padding-top:0!important}.headerinpos_below .l-header.pos_fixed~.l-main .l-section.full_height:nth-of-type(2){min-height:100vh}.headerinpos_below .l-header.pos_fixed~.l-main>.l-section:nth-of-type(2)>.l-section-h{padding-top:var(--header-height)}.headerinpos_bottom .l-header.pos_fixed:not(.sticky){position:absolute;top:100vh}.headerinpos_bottom .l-header.pos_fixed~.l-main>.l-section:first-of-type>.l-section-h{padding-top:0!important}.headerinpos_bottom .l-header.pos_fixed~.l-main>.l-section:first-of-type>.l-section-h{padding-bottom:var(--header-height)}.headerinpos_bottom .l-header.pos_fixed.bg_transparent~.l-main .l-section.valign_center:not(.height_auto):first-of-type>.l-section-h{top:calc( var(--header-height) / 2 )}.headerinpos_bottom .l-header.pos_fixed:not(.sticky) .w-cart-dropdown,.headerinpos_bottom .l-header.pos_fixed:not(.sticky) .w-nav.type_desktop .w-nav-list.level_2{bottom:100%;transform-origin:0 100%}.headerinpos_bottom .l-header.pos_fixed:not(.sticky) .w-nav.type_mobile.m_layout_dropdown .w-nav-list.level_1{top:auto;bottom:100%;box-shadow:var(--box-shadow-up)}.headerinpos_bottom .l-header.pos_fixed:not(.sticky) .w-nav.type_desktop .w-nav-list.level_3,.headerinpos_bottom .l-header.pos_fixed:not(.sticky) .w-nav.type_desktop .w-nav-list.level_4{top:auto;bottom:0;transform-origin:0 100%}.headerinpos_bottom .l-header.pos_fixed:not(.sticky) .w-dropdown-list{top:auto;bottom:-0.4em;padding-top:0.4em;padding-bottom:2.4em}.admin-bar .l-header.pos_static.bg_solid~.l-main .l-section.full_height:first-of-type{min-height:calc( 100vh - var(--header-height) - 32px )}.admin-bar .l-header.pos_fixed:not(.sticky_auto_hide)~.l-main .l-section.full_height:not(:first-of-type){min-height:calc( 100vh - var(--header-sticky-height) - 32px )}.admin-bar.headerinpos_below .l-header.pos_fixed~.l-main .l-section.full_height:nth-of-type(2){min-height:calc(100vh - 32px)}}@media (min-width:601px) and (max-width:1024px){.hidden_for_tablets{display:none!important}.l-subheader.at_top{display:none}.l-subheader.at_bottom{display:none}.l-header{position:relative;z-index:111;width:100%}.l-subheader{margin:0 auto}.l-subheader.width_full{padding-left:1.5rem;padding-right:1.5rem}.l-subheader-h{display:flex;align-items:center;position:relative;margin:0 auto;max-width:var(--site-content-width,1200px);height:inherit}.w-header-show{display:none}.l-header.pos_fixed{position:fixed;left:0}.l-header.pos_fixed:not(.notransition) .l-subheader{transition-property:transform,background,box-shadow,line-height,height;transition-duration:.3s;transition-timing-function:cubic-bezier(.78,.13,.15,.86)}.headerinpos_bottom.sticky_first_section .l-header.pos_fixed{position:fixed!important}.header_hor .l-header.sticky_auto_hide{transition:transform .3s cubic-bezier(.78,.13,.15,.86) .1s}.header_hor .l-header.sticky_auto_hide.down{transform:translateY(-110%)}.l-header.bg_transparent:not(.sticky) .l-subheader{box-shadow:none!important;background:none}.l-header.bg_transparent~.l-main .l-section.width_full.height_auto:first-of-type>.l-section-h{padding-top:0!important;padding-bottom:0!important}.l-header.pos_static.bg_transparent{position:absolute;left:0}.l-subheader.width_full .l-subheader-h{max-width:none!important}.l-header.shadow_thin .l-subheader.at_middle,.l-header.shadow_thin .l-subheader.at_bottom{box-shadow:0 1px 0 rgba(0,0,0,0.08)}.l-header.shadow_wide .l-subheader.at_middle,.l-header.shadow_wide .l-subheader.at_bottom{box-shadow:0 3px 5px -1px rgba(0,0,0,0.1),0 2px 1px -1px rgba(0,0,0,0.05)}.header_hor .l-subheader-cell>.w-cart{margin-left:0;margin-right:0}:root{--header-height:100px;--header-sticky-height:80px}.l-header:before{content:'100'}.l-header.sticky:before{content:'80'}.l-subheader.at_top{line-height:40px;height:40px}.l-header.sticky .l-subheader.at_top{line-height:40px;height:40px}.l-subheader.at_middle{line-height:100px;height:100px}.l-header.sticky .l-subheader.at_middle{line-height:80px;height:80px}.l-subheader.at_bottom{line-height:50px;height:50px}.l-header.sticky .l-subheader.at_bottom{line-height:50px;height:50px}}@media (max-width:600px){.hidden_for_mobiles{display:none!important}.l-subheader.at_top{display:none}.l-subheader.at_bottom{display:none}.l-header{position:relative;z-index:111;width:100%}.l-subheader{margin:0 auto}.l-subheader.width_full{padding-left:1.5rem;padding-right:1.5rem}.l-subheader-h{display:flex;align-items:center;position:relative;margin:0 auto;max-width:var(--site-content-width,1200px);height:inherit}.w-header-show{display:none}.l-header.pos_fixed{position:fixed;left:0}.l-header.pos_fixed:not(.notransition) .l-subheader{transition-property:transform,background,box-shadow,line-height,height;transition-duration:.3s;transition-timing-function:cubic-bezier(.78,.13,.15,.86)}.headerinpos_bottom.sticky_first_section .l-header.pos_fixed{position:fixed!important}.header_hor .l-header.sticky_auto_hide{transition:transform .3s cubic-bezier(.78,.13,.15,.86) .1s}.header_hor .l-header.sticky_auto_hide.down{transform:translateY(-110%)}.l-header.bg_transparent:not(.sticky) .l-subheader{box-shadow:none!important;background:none}.l-header.bg_transparent~.l-main .l-section.width_full.height_auto:first-of-type>.l-section-h{padding-top:0!important;padding-bottom:0!important}.l-header.pos_static.bg_transparent{position:absolute;left:0}.l-subheader.width_full .l-subheader-h{max-width:none!important}.l-header.shadow_thin .l-subheader.at_middle,.l-header.shadow_thin .l-subheader.at_bottom{box-shadow:0 1px 0 rgba(0,0,0,0.08)}.l-header.shadow_wide .l-subheader.at_middle,.l-header.shadow_wide .l-subheader.at_bottom{box-shadow:0 3px 5px -1px rgba(0,0,0,0.1),0 2px 1px -1px rgba(0,0,0,0.05)}.header_hor .l-subheader-cell>.w-cart{margin-left:0;margin-right:0}:root{--header-height:70px;--header-sticky-height:70px}.l-header:before{content:'70'}.l-header.sticky:before{content:'70'}.l-subheader.at_top{line-height:40px;height:40px}.l-header.sticky .l-subheader.at_top{line-height:40px;height:40px}.l-subheader.at_middle{line-height:70px;height:70px}.l-header.sticky .l-subheader.at_middle{line-height:70px;height:70px}.l-subheader.at_bottom{line-height:50px;height:50px}.l-header.sticky .l-subheader.at_bottom{line-height:50px;height:50px}}@media (min-width:1381px){.ush_image_1{height:40px!important}.l-header.sticky .ush_image_1{height:40px!important}}@media (min-width:1025px) and (max-width:1380px){.ush_image_1{height:30px!important}.l-header.sticky .ush_image_1{height:30px!important}}@media (min-width:601px) and (max-width:1024px){.ush_image_1{height:30px!important}.l-header.sticky .ush_image_1{height:30px!important}}@media (max-width:600px){.ush_image_1{height:30px!important}.l-header.sticky .ush_image_1{height:30px!important}}.header_hor .ush_menu_1.type_desktop .menu-item.level_1>a:not(.w-btn){padding-left:1vw;padding-right:1vw}.header_hor .ush_menu_1.type_desktop .menu-item.level_1>a.w-btn{margin-left:1vw;margin-right:1vw}.header_hor .ush_menu_1.type_desktop.align-edges>.w-nav-list.level_1{margin-left:-1vw;margin-right:-1vw}.header_ver .ush_menu_1.type_desktop .menu-item.level_1>a:not(.w-btn){padding-top:1vw;padding-bottom:1vw}.header_ver .ush_menu_1.type_desktop .menu-item.level_1>a.w-btn{margin-top:1vw;margin-bottom:1vw}.ush_menu_1.type_desktop .menu-item:not(.level_1){font-size:1rem}.ush_menu_1.type_mobile .w-nav-anchor.level_1,.ush_menu_1.type_mobile .w-nav-anchor.level_1 + .w-nav-arrow{font-size:1.1rem}.ush_menu_1.type_mobile .w-nav-anchor:not(.level_1),.ush_menu_1.type_mobile .w-nav-anchor:not(.level_1) + .w-nav-arrow{font-size:0.9rem}@media (min-width:1381px){.ush_menu_1 .w-nav-icon{font-size:36px}}@media (min-width:1025px) and (max-width:1380px){.ush_menu_1 .w-nav-icon{font-size:32px}}@media (min-width:601px) and (max-width:1024px){.ush_menu_1 .w-nav-icon{font-size:28px}}@media (max-width:600px){.ush_menu_1 .w-nav-icon{font-size:24px}}.ush_menu_1 .w-nav-icon>div{border-width:3px}@media screen and (max-width:899px){.w-nav.ush_menu_1>.w-nav-list.level_1{display:none}.ush_menu_1 .w-nav-control{display:block}}.ush_menu_1 .w-nav-item.level_1>a:not(.w-btn):focus,.no-touch .ush_menu_1 .w-nav-item.level_1.opened>a:not(.w-btn),.no-touch .ush_menu_1 .w-nav-item.level_1:hover>a:not(.w-btn){background:transparent;color:var(--color-header-middle-text-hover)}.ush_menu_1 .w-nav-item.level_1.current-menu-item>a:not(.w-btn),.ush_menu_1 .w-nav-item.level_1.current-menu-ancestor>a:not(.w-btn),.ush_menu_1 .w-nav-item.level_1.current-page-ancestor>a:not(.w-btn){background:transparent;color:var(--color-header-middle-text-hover)}.l-header.bg_transparent:not(.sticky) .ush_menu_1.type_desktop .w-nav-item.level_1.current-menu-item>a:not(.w-btn),.l-header.bg_transparent:not(.sticky) .ush_menu_1.type_desktop .w-nav-item.level_1.current-menu-ancestor>a:not(.w-btn),.l-header.bg_transparent:not(.sticky) .ush_menu_1.type_desktop .w-nav-item.level_1.current-page-ancestor>a:not(.w-btn){background:transparent;color:var(--color-header-middle-text-hover)}.ush_menu_1 .w-nav-list:not(.level_1){background:var(--color-header-middle-bg);color:var(--color-header-middle-text)}.no-touch .ush_menu_1 .w-nav-item:not(.level_1)>a:focus,.no-touch .ush_menu_1 .w-nav-item:not(.level_1):hover>a{background:transparent;color:var(--color-header-middle-text-hover)}.ush_menu_1 .w-nav-item:not(.level_1).current-menu-item>a,.ush_menu_1 .w-nav-item:not(.level_1).current-menu-ancestor>a,.ush_menu_1 .w-nav-item:not(.level_1).current-page-ancestor>a{background:transparent;color:var(--color-header-middle-text-hover)}.ush_image_1{margin-bottom:-6px!important;padding-right:20px!important}.ush_menu_1{font-size:18px!important;font-family:var(--h1-font-family)!important;font-weight:600!important}.ush_btn_1{font-size:13px!important;padding:10px 18px 10px 18px!important}.ush_btn_2{font-size:13px!important;margin-left:auto!important;padding:10px 18px 10px 18px!important}@media (min-width:1025px) and (max-width:1380px){.ush_menu_1{font-size:20px!important;font-weight:600!important}}@media (min-width:601px) and (max-width:1024px){.ush_menu_1{font-size:20px!important;font-weight:600!important}}@media (max-width:600px){.ush_menu_1{font-size:22px!important;font-weight:600!important}}</style>
      <style id="us-design-options-css">.us_custom_f2b35e36{background-blend-mode:color!important;background:rgba(247,247,247,0.85) url(/assets/media/jess-bailey-l3N9Q27zULw-unsplash.jpg) no-repeat 0 50% / cover!important}.us_custom_d96237bc{font-size:0.9rem!important;line-height:1.7!important}.us_custom_4f55d126{text-align:center!important;font-weight:600!important;margin-top:20px!important}.us_custom_b4198c51{font-size:1.2rem!important}.us_custom_38e07046{max-width:700px!important}.us_custom_4481559d{max-width:400px!important}.us_custom_c70c97eb{background:var(--color-content-bg-alt)!important}.us_custom_81dbcac1{border-radius:40px!important}.us_custom_0db20381{background:var(--color-content-secondary)!important}.us_custom_4c31c404{color:var(--color-content-bg-alt)!important;max-width:700px!important;margin-left:auto!important;margin-right:auto!important}.us_custom_cd7939b3{max-width:880px!important;margin-left:auto!important;margin-right:auto!important}.us_custom_9b7142cb{border-radius:10px!important;padding:0!important;background:var(--color-content-bg)!important;box-shadow:0 10px 30px 0 rgba(15,19,31,0.10)!important}.us_custom_8c62bf76{min-height:600px!important;padding:12%!important}.us_custom_7f6554ec{color:var(--color-header-middle-text)!important;font-size:1.2rem!important;font-weight:700!important}.us_custom_168e63a2{font-size:max( 3rem,2vw )!important;margin-bottom:0!important;padding-bottom:0!important}.us_custom_57e1857c{color:var(--color-content-heading)!important;font-size:max( 1rem,1vw )!important}.us_custom_8d8ec63c{color:var(--color-content-heading)!important;font-size:14px!important;margin-top:-20px!important}.us_custom_e471d6ae{margin-bottom:auto!important}.us_custom_e9f23b39{color:#8c8c8c!important;min-height:600px!important;padding:12%!important}.us_custom_74cbc56e{background:#d4d4d4!important}.us_custom_29a21d1c{max-width:880px!important;margin-left:auto!important;margin-right:auto!important;border-radius:10px!important;padding:3rem!important;border:2px solid var(--color-content-border)!important}.us_custom_e4c01883{color:var(--color-header-middle-text)!important;font-size:1.2rem!important;font-weight:600!important}.us_custom_e5cabf0a{border-radius:6px!important;padding:10%!important;background:var(--color-content-bg)!important;box-shadow:0 10px 50px 0 rgba(0,0,0,0.08)!important}.us_custom_9d3767a8{text-align:center!important;max-width:790px!important;margin-left:auto!important;margin-right:auto!important}.us_custom_eb849559{text-align:center!important}.us_custom_de82079f{text-align:center!important;font-size:25px!important}@media (min-width:1025px) and (max-width:1380px){.us_custom_29a21d1c{margin-left:auto!important;margin-right:auto!important;padding:3rem!important}}@media (min-width:601px) and (max-width:1024px){.us_custom_29a21d1c{margin-left:auto!important;margin-right:auto!important;padding:3rem!important}}@media (max-width:600px){.us_custom_29a21d1c{margin-left:auto!important;margin-right:auto!important;padding:1.5rem!important}}</style>
   </head>
   <body class="home page-template-default page page-id-8 l-body Impreza_8.19 us-core_8.19.2 headerinpos_top wpb-js-composer js-comp-ver-7.2 vc_responsive header_hor state_default" itemscope="" itemtype="https://schema.org/WebPage">
      <div class="l-canvas type_wide">
         <header id="page-header" class="l-header pos_fixed shadow_thin bg_transparent id_13" itemscope itemtype="https://schema.org/WPHeader">
            <div class="l-subheader at_middle">
               <div class="l-subheader-h">
                  <div class="l-subheader-cell at_left">
                     <div class="w-image ush_image_1"><a href="/" aria-label="Logo_Transparante-achtergrond" class="w-image-h"><img width="2783" height="696" src="https://propixel.nl/wp-content/uploads/2024/01/Logo_Transparante-achtergrond.png" class="attachment-full size-full" alt="" decoding="async" fetchpriority="high" srcset="https://propixel.nl/wp-content/uploads/2024/01/Logo_Transparante-achtergrond.png 2783w, https://propixel.nl/wp-content/uploads/2024/01/Logo_Transparante-achtergrond-300x75.png 300w, https://propixel.nl/wp-content/uploads/2024/01/Logo_Transparante-achtergrond-1024x256.png 1024w" sizes="(max-width: 2783px) 100vw, 2783px" /></a></div>
                     <nav class="w-nav type_desktop ush_menu_1 height_full dropdown_height m_align_none m_layout_dropdown" itemscope itemtype="https://schema.org/SiteNavigationElement">
                        <a class="w-nav-control" aria-label="Menu" href="#">
                           <div class="w-nav-icon">
                              <div></div>
                           </div>
                        </a>
                        <ul class="w-nav-list level_1 hide_for_mobiles hover_simple">
                           <li id="menu-item-58" class="menu-item menu-item-type-custom menu-item-object-custom w-nav-item level_1 menu-item-58"><a class="w-nav-anchor level_1" href="#top"><span class="w-nav-title">Home</span><span class="w-nav-arrow"></span></a></li>
                           <li id="menu-item-10" class="menu-item menu-item-type-custom menu-item-object-custom w-nav-item level_1 menu-item-10"><a class="w-nav-anchor level_1" href="#over"><span class="w-nav-title">Over</span><span class="w-nav-arrow"></span></a></li>
                           <li id="menu-item-11" class="menu-item menu-item-type-custom menu-item-object-custom w-nav-item level_1 menu-item-11"><a class="w-nav-anchor level_1" href="#prijzen"><span class="w-nav-title">Prijzen</span><span class="w-nav-arrow"></span></a></li>
                           <li id="menu-item-12" class="menu-item menu-item-type-custom menu-item-object-custom w-nav-item level_1 menu-item-12"><a class="w-nav-anchor level_1" href="#contact"><span class="w-nav-title">Contact</span><span class="w-nav-arrow"></span></a></li>
                           <li class="w-nav-close"></li>
                        </ul>
                        <div class="w-nav-options hidden" onclick='return {&quot;mobileWidth&quot;:900,&quot;mobileBehavior&quot;:1}'></div>
                     </nav>
                  </div>
                  <div class="l-subheader-cell at_center"></div>
                  <div class="l-subheader-cell at_right"><a class="w-btn us-btn-style_1 hidden_for_tablets hidden_for_mobiles ush_btn_2" href="mailto:info@propixel.nl"><span class="w-btn-label">info@propixel.nl</span></a><a class="w-btn us-btn-style_1 hidden_for_tablets hidden_for_mobiles ush_btn_1" href="tel:085 &#8211; 0123 123"><span class="w-btn-label">085 &#8211; 0123 123</span></a></div>
               </div>
            </div>
            <div class="l-subheader for_hidden hidden"></div>
         </header>
         <main id="page-content" class="l-main" itemprop="mainContentOfPage">
            <section class="l-section wpb_row us_custom_f2b35e36 height_auto width_custom" style="--site-content-width:800px;" id="top">
               <div class="l-section-h i-cf">
                  <div class="g-cols vc_row via_grid cols_1 laptops-cols_inherit tablets-cols_inherit mobiles-cols_1 valign_top type_default stacking_default">
                     <div class="wpb_column vc_column_container">
                        <div class="vc_column-inner">
                           <div class="w-separator size_custom" style="height:15vmin"></div>
                           <div class="wpb_text_column us_custom_d96237bc">
                              <div class="wpb_wrapper">
                                 <p style="text-align: center;">Beoordeeld door onze klanten met:</p>
                              </div>
                           </div>
                           <div class="w-hwrapper valign_middle align_center" style="--hwrapper-gap:0.5rem">
                              <div class="w-iconbox iconpos_top style_default color_primary align_center no_text no_title">
                                 <div class="w-iconbox-icon" style="font-size:1.5rem;"><i class="fas fa-star"></i></div>
                                 <div class="w-iconbox-meta"></div>
                              </div>
                              <div class="w-iconbox iconpos_top style_default color_primary align_center no_text no_title">
                                 <div class="w-iconbox-icon" style="font-size:1.5rem;"><i class="fas fa-star"></i></div>
                                 <div class="w-iconbox-meta"></div>
                              </div>
                              <div class="w-iconbox iconpos_top style_default color_primary align_center no_text no_title">
                                 <div class="w-iconbox-icon" style="font-size:1.5rem;"><i class="fas fa-star"></i></div>
                                 <div class="w-iconbox-meta"></div>
                              </div>
                              <div class="w-iconbox iconpos_top style_default color_primary align_center no_text no_title">
                                 <div class="w-iconbox-icon" style="font-size:1.5rem;"><i class="fas fa-star"></i></div>
                                 <div class="w-iconbox-meta"></div>
                              </div>
                              <div class="w-iconbox iconpos_top style_default color_primary align_center no_text no_title">
                                 <div class="w-iconbox-icon" style="font-size:1.5rem;"><i class="fas fa-star"></i></div>
                                 <div class="w-iconbox-meta"></div>
                              </div>
                              <div class="w-text"><span class="w-text-h"><span class="w-text-value">4.8</span></span></div>
                           </div>
                           <h1 class="w-text us_custom_4f55d126"><span class="w-text-h"><span class="w-text-value">De intelligente alles in één oplossing voor uw websites</span></span></h1>
                           <div class="w-separator size_medium"></div>
                           <div class="w-hwrapper valign_middle wrap align_center" style="--hwrapper-gap:2rem">
                              <div class="w-btn-wrapper align_none"><a class="w-btn us-btn-style_1 us_custom_b4198c51" href="#"><span class="w-btn-label">Start Nu</span></a></div>
                              <div class="wpb_text_column us_custom_d96237bc">
                                 <div class="wpb_wrapper">
                                    <p style="text-align: left;"><strong>Wij realiseren jouw website</strong><br>binnen 24 uur!</p>
                                 </div>
                              </div>
                           </div>
                           <div class="w-separator size_custom" style="height:15vmin"></div>
                        </div>
                     </div>
                  </div>
               </div>
            </section>
            <section class="l-section wpb_row height_medium" id="over">
               <div class="l-section-h i-cf">
                  <div class="g-cols vc_row via_grid cols_1 laptops-cols_inherit tablets-cols_inherit mobiles-cols_1 valign_top type_default stacking_default">
                     <div class="wpb_column vc_column_container">
                        <div class="vc_column-inner">
                           <h2 class="w-text us_custom_38e07046"><span class="w-text-h"><span class="w-text-value">Een website realiseren was nog nooit zo eenvoudig en snel!</span></span></h2>
                           <div class="w-separator size_medium"></div>
                           <div class="g-cols wpb_row via_grid cols_3 laptops-cols_inherit tablets-cols_2 mobiles-cols_1 valign_top type_default stacking_default" style="--gap:3rem;">
                              <div class="wpb_column vc_column_container hide_on_tablets hide_on_mobiles">
                                 <div class="vc_column-inner">
                                    <div class="w-image has_ratio align_none">
                                       <div class="w-image-h">
                                          <div style="padding-bottom:150%"></div>
                                          <img decoding="async" width="1024" height="683" src="/assets/media/scott-graham-5fNmWej4tAA-unsplash-1024x683.jpg" class="attachment-large size-large" alt="" srcset="/assets/media/scott-graham-5fNmWej4tAA-unsplash-1024x683.jpg 1024w, /assets/media/scott-graham-5fNmWej4tAA-unsplash-300x200.jpg 300w, /assets/media/scott-graham-5fNmWej4tAA-unsplash.jpg 1920w" sizes="(max-width: 1024px) 100vw, 1024px">
                                       </div>
                                    </div>
                                 </div>
                              </div>
                              <div class="wpb_column vc_column_container hide_on_tablets hide_on_mobiles">
                                 <div class="vc_column-inner">
                                    <div class="w-image has_ratio align_none">
                                       <div class="w-image-h">
                                          <div style="padding-bottom:150%"></div>
                                          <img decoding="async" width="683" height="1024" src="assets/media/bill-jelen-NVWyN8GamCk-unsplash-683x1024.jpg" class="attachment-large size-large" alt="" srcset="/assets/media/bill-jelen-NVWyN8GamCk-unsplash-683x1024.jpg 683w, /assets/media/bill-jelen-NVWyN8GamCk-unsplash-200x300.jpg 200w, /assets/media/bill-jelen-NVWyN8GamCk-unsplash-scaled.jpg 1707w" sizes="(max-width: 683px) 100vw, 683px">
                                       </div>
                                    </div>
                                 </div>
                              </div>
                              <div class="wpb_column vc_column_container">
                                 <div class="vc_column-inner">
                                    <div class="wpb_text_column us_custom_4481559d">
                                       <div class="wpb_wrapper">
                                          <p>Wij zijn meer dan een webontwikkelingsbedrijf; we zijn jouw strategische partner in het bouwen van een sterke online aanwezigheid. Met <strong>onze alles-in-één oplossing</strong>, van ontwerp tot hosting en onderhoud, willen wij jouw digitale visie op een intelligente manier realiseren.</p>
                                          <p>Wij geloven in het vereenvoudigen van online succes voor bedrijven van elke omvang, of je nu net begint of al lang bestaat. Onze missie is om hoogwaardige websites te leveren die aansluiten bij uw branche, uitblinken in prestaties en functionaliteit, middels transparante tarieven, toegewijde ondersteuning en continue verbetering.</p>
                                       </div>
                                    </div>
                                    <div class="w-separator size_medium"></div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </section>
            <section class="l-section wpb_row us_custom_c70c97eb height_medium">
               <div class="l-section-h i-cf">
                  <div class="g-cols vc_row via_grid cols_1 laptops-cols_inherit tablets-cols_inherit mobiles-cols_1 valign_top type_default stacking_default" style="--gap:0rem;">
                     <div class="wpb_column vc_column_container">
                        <div class="vc_column-inner">
                           <div class="w-separator size_medium"></div>
                           <div class="wpb_text_column">
                              <div class="wpb_wrapper">
                                 <h2 style="text-align: center;">Waarom een website van ProPixel?</h2>
                              </div>
                           </div>
                           <div class="w-separator size_large"></div>
                           <div class="g-cols wpb_row via_grid cols_2 laptops-cols_inherit tablets-cols_1 mobiles-cols_1 valign_middle type_default stacking_default" style="--gap:3rem;">
                              <div class="wpb_column vc_column_container">
                                 <div class="vc_column-inner">
                                    <div class="w-iconbox iconpos_left style_default color_secondary align_left">
                                       <div class="w-iconbox-icon" style="font-size:50px;"><i class="fas fa-pencil-ruler"></i></div>
                                       <div class="w-iconbox-meta">
                                          <h4 class="w-iconbox-title">Website al binnen 1 dag</h4>
                                          <div class="w-iconbox-text">
                                             <p>ProPixel levert uw professionele website binnen 24 uur, van tekst tot afbeeldingen: snel, efficiënt en klaar om te schitteren.</p>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="w-separator size_large"></div>
                                    <div class="w-iconbox iconpos_left style_default color_secondary align_left">
                                       <div class="w-iconbox-icon" style="font-size:50px;"><i class="fas fa-thumbs-up"></i></div>
                                       <div class="w-iconbox-meta">
                                          <h4 class="w-iconbox-title">Eén prijs, Alles inbegrepen</h4>
                                          <div class="w-iconbox-text">
                                             <p>Wij bieden een volledig pakket inclusief website, hosting, domeinnaam, periodiek onderhoud en regelmatige updates – zonder verborgen kosten.</p>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="w-separator size_large"></div>
                                    <div class="w-iconbox iconpos_left style_default color_secondary align_left">
                                       <div class="w-iconbox-icon" style="font-size:50px;"><i class="fas fa-rabbit-fast"></i></div>
                                       <div class="w-iconbox-meta">
                                          <h4 class="w-iconbox-title">Veilig, Snel en SEO-vriendelijk</h4>
                                          <div class="w-iconbox-text">
                                             <p>Onze websites zijn snel, up-to-date en geoptimaliseerd voor zoekmachines, voor maximale online zichtbaarheid.</p>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                              <div class="wpb_column vc_column_container">
                                 <div class="vc_column-inner">
                                    <div class="w-image us_custom_81dbcac1 has_ratio align_none">
                                       <div class="w-image-h">
                                          <div style="padding-bottom:100%"></div>
                                          <img decoding="async" width="819" height="1024" src="/assets/media/saffu-E4kKGI4oGaU-unsplash-819x1024.jpg" class="attachment-large size-large" alt="" srcset="/assets/media/saffu-E4kKGI4oGaU-unsplash-819x1024.jpg 819w, /assets/media/saffu-E4kKGI4oGaU-unsplash-240x300.jpg 240w, /assets/media/saffu-E4kKGI4oGaU-unsplash.jpg 1920w" sizes="(max-width: 819px) 100vw, 819px">
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <div class="w-separator size_large"></div>
                        </div>
                     </div>
                  </div>
               </div>
            </section>
            <section class="l-section wpb_row us_custom_0db20381 height_medium with_shape" id="prijzen">
               <div class="l-section-shape type_custom pos_bottom hor_flip" style="height:40%;">
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 8" preserveAspectRatio="none" width="100%" height="100%">
                     <path fill="currentColor" d="M64 8 L0 8 L0 0 L64 0 Z"></path>
                  </svg>
               </div>
               <div class="l-section-h i-cf">
                  <div class="g-cols vc_row via_grid cols_1 laptops-cols_inherit tablets-cols_inherit mobiles-cols_1 valign_top type_default stacking_default">
                     <div class="wpb_column vc_column_container">
                        <div class="vc_column-inner">
                           <div class="wpb_text_column us_custom_4c31c404 has_text_color">
                              <div class="wpb_wrapper">
                                 <h2 style="text-align: center;">Eén Prijs voor Compleet Gemak en Succes!</h2>
                                 <p style="text-align: center;">Bespaar tijd en gedoe! Laat uw website door professionals bouwen. Eén tarief, alles inbegrepen. Wij regelen teksten, foto’s, optimalisatie voor zoekmachines en blijvende functionaliteit. Klaar voor succes? Start nu!</p>
                              </div>
                           </div>
                           <div class="w-separator size_large"></div>
                           <div class="g-cols wpb_row us_custom_cd7939b3 via_grid cols_2 laptops-cols_2 tablets-cols_1 mobiles-cols_1 valign_top type_default stacking_default" style="--gap:2rem;">
                              <div class="wpb_column vc_column_container us_custom_9b7142cb has_bg_color">
                                 <div class="vc_column-inner">
                                    <div class="w-vwrapper us_custom_8c62bf76 align_none valign_top" style="--vwrapper-gap:0.5rem">
                                       <h3 class="w-text us_custom_7f6554ec has_text_color"><span class="w-text-h"><span class="w-text-value">Startup</span></span></h3>
                                       <div class="w-hwrapper valign_baseline align_none" style="--hwrapper-gap:0.4rem">
                                          <h4 class="w-text us_custom_168e63a2"><span class="w-text-h"><span class="w-text-value">€55</span></span></h4>
                                          <div class="w-text us_custom_57e1857c has_text_color"><span class="w-text-h"><span class="w-text-value">/maand</span></span></div>
                                       </div>
                                       <div class="wpb_text_column us_custom_8d8ec63c has_text_color">
                                          <div class="wpb_wrapper">
                                             <p style="text-align: left;">Jaarlijkse facturatie</p>
                                          </div>
                                       </div>
                                       <div class="wpb_text_column">
                                          <div class="wpb_wrapper">
                                             <p>Kies voor een one-pager website, perfect voor startups!</p>
                                          </div>
                                       </div>
                                       <div class="w-separator size_small"></div>
                                       <div class="w-text icon_atleft"><span class="w-text-h"><i class="material-icons">check</i><span class="w-text-value">One-pager website</span></span></div>
                                       <div class="w-text icon_atleft"><span class="w-text-h"><i class="material-icons">check</i><span class="w-text-value">Inclusief ontwerp en realisatie</span></span></div>
                                       <div class="w-text icon_atleft"><span class="w-text-h"><i class="material-icons">check</i><span class="w-text-value">Inclusief tekst en afbeeldingen</span></span></div>
                                       <div class="w-text icon_atleft"><span class="w-text-h"><i class="material-icons">check</i><span class="w-text-value">Webhosting en Domeinnaam</span></span></div>
                                       <div class="w-text icon_atleft"><span class="w-text-h"><i class="material-icons">check</i><span class="w-text-value">SSL Certificaat</span></span></div>
                                       <div class="w-text icon_atleft"><span class="w-text-h"><i class="material-icons">check</i><span class="w-text-value">Onderhoud en Updates</span></span></div>
                                       <div class="w-text icon_atleft"><span class="w-text-h"><i class="material-icons">check</i><span class="w-text-value">SEO Geoptimaliseerd</span></span></div>
                                       <div class="w-separator us_custom_e471d6ae size_small"></div>
                                       <div class="w-btn-wrapper align_justify"><a class="w-btn us-btn-style_1" href="#contact"><span class="w-btn-label">Start vandaag nog!</span></a></div>
                                    </div>
                                 </div>
                              </div>
                              <div class="wpb_column vc_column_container us_custom_9b7142cb has_bg_color">
                                 <div class="vc_column-inner">
                                    <div class="w-vwrapper us_custom_e9f23b39 has_text_color align_none valign_top" style="--vwrapper-gap:0.5rem">
                                       <h3 class="w-text us_custom_7f6554ec has_text_color"><span class="w-text-h"><span class="w-text-value">Business (Binnenkort)</span></span></h3>
                                       <div class="w-hwrapper valign_baseline align_none" style="--hwrapper-gap:0.4rem">
                                          <h4 class="w-text us_custom_168e63a2"><span class="w-text-h"><span class="w-text-value">€99</span></span></h4>
                                          <div class="w-text us_custom_57e1857c has_text_color"><span class="w-text-h"><span class="w-text-value">/maand</span></span></div>
                                       </div>
                                       <div class="wpb_text_column us_custom_8d8ec63c has_text_color">
                                          <div class="wpb_wrapper">
                                             <p style="text-align: left;">Jaarlijkse facturatie</p>
                                          </div>
                                       </div>
                                       <div class="wpb_text_column">
                                          <div class="wpb_wrapper">
                                             <p>Kies voor een krachtige, volwaardige, professionele website!</p>
                                          </div>
                                       </div>
                                       <div class="w-separator size_small"></div>
                                       <div class="w-text icon_atleft"><span class="w-text-h"><i class="material-icons">check</i><span class="w-text-value">Volledige website</span></span></div>
                                       <div class="w-text icon_atleft"><span class="w-text-h"><i class="material-icons">check</i><span class="w-text-value">Inclusief ontwerp en realisatie</span></span></div>
                                       <div class="w-text icon_atleft"><span class="w-text-h"><i class="material-icons">check</i><span class="w-text-value">Inclusief tekst en afbeeldingen</span></span></div>
                                       <div class="w-text icon_atleft"><span class="w-text-h"><i class="material-icons">check</i><span class="w-text-value">Webhosting en Domeinnaam</span></span></div>
                                       <div class="w-text icon_atleft"><span class="w-text-h"><i class="material-icons">check</i><span class="w-text-value">SSL Certificaat</span></span></div>
                                       <div class="w-text icon_atleft"><span class="w-text-h"><i class="material-icons">check</i><span class="w-text-value">Onderhoud en Updates</span></span></div>
                                       <div class="w-text icon_atleft"><span class="w-text-h"><i class="material-icons">check</i><span class="w-text-value">SEO Geoptimaliseerd</span></span></div>
                                       <div class="w-text icon_atleft"><span class="w-text-h"><i class="material-icons">check</i><span class="w-text-value">Onbeperkte opties</span></span></div>
                                       <div class="w-separator us_custom_e471d6ae size_small"></div>
                                       <div class="w-btn-wrapper align_justify"><button class="w-btn us-btn-style_1 us_custom_74cbc56e"><span class="w-btn-label">Start vandaag nog!</span></button></div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <div class="w-separator size_custom" style="height:2rem"></div>
                           <div class="g-cols wpb_row us_custom_29a21d1c via_grid cols_3-2 laptops-cols_inherit tablets-cols_1 mobiles-cols_1 valign_middle type_default stacking_default" style="--gap:3vw;">
                              <div class="wpb_column vc_column_container">
                                 <div class="vc_column-inner">
                                    <div class="wpb_text_column">
                                       <div class="wpb_wrapper">
                                          <h4>Meer dan 3 websites nodig?</h4>
                                          <p>Boost je online aanwezigheid! Ontvang een gereduceerd tarief voor meerdere websites. Neem contact op!</p>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                              <div class="wpb_column vc_column_container">
                                 <div class="vc_column-inner">
                                    <div class="w-btn-wrapper default_align_right laptops_align_right tablets_align_left mobiles_align_justify"><a class="w-btn us-btn-style_2" href="#contact"><span class="w-btn-label">Neem contact op!</span></a></div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </section>
            <section class="l-section wpb_row us_custom_c70c97eb height_medium" id="contact">
               <div class="l-section-h i-cf">
                  <div class="g-cols vc_row via_grid cols_2 laptops-cols_inherit tablets-cols_1 mobiles-cols_1 valign_middle type_default stacking_default">
                     <div class="wpb_column vc_column_container">
                        <div class="vc_column-inner">
                           <div class="wpb_text_column">
                              <div class="wpb_wrapper">
                                 <h2>Neem contact op</h2>
                              </div>
                           </div>
                           <div class="w-separator size_medium"></div>
                           <div class="g-cols wpb_row via_grid cols_2 laptops-cols_inherit tablets-cols_inherit mobiles-cols_1 valign_top type_default stacking_default" style="--gap:3rem;">
                              <div class="wpb_column vc_column_container">
                                 <div class="vc_column-inner">
                                    <div class="wpb_text_column">
                                       <div class="wpb_wrapper">
                                          <p>Bel ons voor meer info en vrijblijvend advies.</p>
                                       </div>
                                    </div>
                                    <div class="w-separator size_small"></div>
                                    <div class="w-text us_custom_e4c01883 has_text_color"><a href="tel:085 – 0123 123" class="w-text-h"><span class="w-text-value">085 – 0123 123</span></a></div>
                                 </div>
                              </div>
                              <div class="wpb_column vc_column_container">
                                 <div class="vc_column-inner">
                                    <div class="wpb_text_column">
                                       <div class="wpb_wrapper">
                                          <p>Stuur voor vragen een e-mail naar:</p>
                                       </div>
                                    </div>
                                    <div class="w-separator size_small"></div>
                                    <div class="w-text us_custom_e4c01883 has_text_color"><a href="mailto:info@propixel.nl" class="w-text-h"><span class="w-text-value">info@propixel.nl</span></a></div>
                                 </div>
                              </div>
                           </div>
                           <div class="w-separator size_medium"></div>
                           <div class="g-cols wpb_row via_grid cols_2 laptops-cols_inherit tablets-cols_inherit mobiles-cols_1 valign_top type_default stacking_default" style="--gap:3rem;">
                              <div class="wpb_column vc_column_container">
                                 <div class="vc_column-inner">
                                    <div class="wpb_text_column">
                                       <div class="wpb_wrapper">
                                          <p><strong>ProPixel B.V.</strong><br><span class="fontstyle0">Philippus Robbenstraat 9e<br>7665AA Albergen</span></p>
                                       </div>
                                    </div>
                                    <div class="w-separator size_small"></div>
                                 </div>
                              </div>
                              <div class="wpb_column vc_column_container">
                                 <div class="vc_column-inner">
                                    <div class="wpb_text_column">
                                       <div class="wpb_wrapper">
                                          <p>KvK: <span class="fontstyle0">92602304<br></span>BTW: NL123451234B0</p>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="wpb_column vc_column_container us_custom_e5cabf0a has_bg_color">
                        <div class="vc_column-inner">
                           <form class="w-form  layout_ver for_cform us_form_1" autocomplete="off">
                              <div class="w-form-h">
                              
                                 <div class="w-form-row for_text cols_2">
                                    
                                    <div class="w-form-row-field">
                                       <input aria-label="Naam" type="text" name="name" value="" placeholder="Naam">
                                    </div>
                                    <div class="w-form-row-state">Dit is een verplicht veld</div>
                                 </div>
                                 <div class="w-form-row for_email required cols_2">
                                    <div class="w-form-row-field">
                                       <div class="w-form-error"></div>
                                       <input aria-label="E-mail" type="email" name="email" value="" placeholder="E-mail *" data-required="true" aria-required="true">
                                    </div>
                                    
                                 </div>
                                 <div class="w-form-row for_text">
                                    <div class="w-form-row-field">
                                       <input aria-label="Bedrijfsnaam" type="text" name="company" value="" placeholder="Bedrijfsnaam">
                                    </div>
                                    <div class="w-form-row-state">Dit is een verplicht veld</div>
                                 </div>
                                 <div class="w-form-row for_textarea">
                                    <div class="w-form-row-field">
                                       <textarea aria-label="Uw vraag" name="question" placeholder="Uw vraag"></textarea>
                                    </div>
                                    <div class="w-form-row-state">Dit is een verplicht veld</div>
                                 </div>
                                 <div class="w-form-row for_submit align_justify">
                                    <button class="w-btn  us-btn-style_1" aria-label="Verzenden" type="submit">
                                    <span class="g-preloader type_1"></span>
                                    <span class="w-btn-label">Verzenden</span>
                                    </button>
                                 </div>
                              </div>
                              <div class="success"></div>
                           </form>
                        </div>
                     </div>
                  </div>
               </div>
            </section>
         </main>
      </div>
      <footer id="page-footer" class="l-footer" itemscope="" itemtype="https://schema.org/WPFooter">
         <section class="l-section wpb_row height_medium color_secondary" id="section-09">
            <div class="l-section-h i-cf">
               <div class="g-cols vc_row via_grid cols_1 laptops-cols_inherit tablets-cols_inherit mobiles-cols_1 valign_top type_default stacking_default">
                  <div class="wpb_column vc_column_container">
                     <div class="vc_column-inner">
                        <div class="wpb_text_column us_custom_9d3767a8">
                           <div class="wpb_wrapper">
                              <p>&nbsp;</p>
                              <h3>Jouw Online Succes, Onze Expertise!</h3>
                              <p>Wij staan voor jou klaar!</p>
                           </div>
                        </div>
                        <div class="w-separator size_custom" style="height:50px" id="y666">
                           <style>@media(max-width:609px){ #y666{height:30px!important}}</style>
                        </div>
                        <nav class="w-menu us_custom_eb849559 layout_hor style_links us_menu_1" style="--main-gap:1.5rem;--main-ver-indent:0.8em;--main-hor-indent:0.8em;--main-color:inherit;">
                           <ul id="menu-main-menu-1" class="menu">
                              <li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-58"><a href="#top">Home</a></li>
                              <li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-10 current-menu-item"><a href="#over">Over</a></li>
                              <li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-11"><a href="#prijzen">Prijzen</a></li>
                              <li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-12"><a href="#contact">Contact</a></li>
                           </ul>
                           <style>@media ( max-width:600px ){.us_menu_1 .menu{display:block!important}.us_menu_1 .menu>li{margin:0 0 var(--main-gap,1.5rem)!important}}</style>
                        </nav>
                        <div class="w-separator size_custom" style="height:50px" id="d57f">
                           <style>@media(max-width:609px){ #d57f{height:30px!important}}</style>
                        </div>
                        <div class="w-socials us_custom_de82079f color_text shape_none" style="--gap:0.8em;">
                           <div class="w-socials-list">
                              <div class="w-socials-item facebook">
                                 <a target="_blank" rel="nofollow" href="#" class="w-socials-item-link" title="Facebook" aria-label="Facebook"><span class="w-socials-item-link-hover"></span><i class="fab fa-facebook"></i></a>
                                 <div class="w-socials-item-popup"><span>Facebook</span></div>
                              </div>
                              <div class="w-socials-item linkedin">
                                 <a target="_blank" rel="nofollow" href="#" class="w-socials-item-link" title="LinkedIn" aria-label="LinkedIn"><span class="w-socials-item-link-hover"></span><i class="fab fa-linkedin"></i></a>
                                 <div class="w-socials-item-popup"><span>LinkedIn</span></div>
                              </div>
                              <div class="w-socials-item twitter">
                                 <a target="_blank" rel="nofollow" href="#" class="w-socials-item-link" title="Twitter" aria-label="Twitter">
                                    <span class="w-socials-item-link-hover"></span>
                                    <i class="fab fa-x-twitter">
                                       <svg style="width:1em; margin-bottom:-.1em;" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                          <path fill="currentColor" d="M389.2 48h70.6L305.6 224.2 487 464H345L233.7 318.6 106.5 464H35.8L200.7 275.5 26.8 48H172.4L272.9 180.9 389.2 48zM364.4 421.8h39.1L151.1 88h-42L364.4 421.8z"></path>
                                       </svg>
                                    </i>
                                 </a>
                                 <div class="w-socials-item-popup"><span>Twitter</span></div>
                              </div>
                           </div>
                        </div>
                        <div class="w-separator size_custom" style="height:50px" id="jbbb">
                           <style>@media(max-width:609px){ #jbbb{height:30px!important}}</style>
                        </div>
                        <div class="wpb_text_column">
                           <div class="wpb_wrapper">
                              <p style="text-align: center;">© ProPixel B.V.</p>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </section>

         <?php
      if ($_SERVER["REQUEST_METHOD"] == "POST") {
         // Process form data
         $name = $_POST["name"];
         $email = $_POST["email"];
         $company = $_POST["company"];
         $question = $_POST["question"];
         
         // Perform any necessary validation
         
         // If validation passes, you can proceed with further actions (e.g., sending an email, saving to database, etc.)
         
         // For example, sending an email notification
         $to = "info@propixel.nl";
         $subject = "Contactformulier";
         $message = "Name: $name\nEmail: $email\nCompany: $company\nQuestion: $question";
         $headers = "From: website@propixel.nl";

         // Send email
         mail($to, $subject, $message, $headers);
         
         exit;
      }
      ?>

<script>
    document.addEventListener("DOMContentLoaded", function() {
        var form = document.querySelector('.w-form');
        var formMessage = form.querySelector('.success');

        form.addEventListener('submit', function(event) {
            event.preventDefault(); // Prevent the form from submitting

            var formData = new FormData(form);
            var formIsValid = true;

            // Clear previous error messages
            formMessage.innerHTML = '';

            // Validate form fields
            form.querySelectorAll('.w-form-row').forEach(function(row) {
               var input = row.querySelector('input[type="email"]');
               var error = row.querySelector('.w-form-error');

               if (input) {
                  if (input.value.trim() === '') {
                        formIsValid = false;
                        if (error) {
                           error.textContent = 'Je moet een email opgeven';
                           error.style.color = 'red';
                        }
                  } else {
                        if (error) {
                           error.textContent = ''; // Clear error message if input is not empty
                        }
                  }
               }
            });

            // If the form is valid, proceed with form submission
            if (formIsValid) {
                var params = new URLSearchParams();

                for (const pair of formData) {
                    params.append(pair[0], pair[1]);
                }

                fetch(window.location.href, {
                    method: 'POST',
                    body: params,
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded'
                    }
                })
                    .then(response => {
                        if (response.ok) {
                            form.reset();
                            // Display success message with form values
                            var successMessage = 'Formulier succesvol verzonden!<br>';
                            formMessage.innerHTML = successMessage;
                            formMessage.style.color = 'green';
                        } else {
                            throw new Error('Form submission failed!');
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        formMessage.textContent = 'Formulier verzending mislukt. Probeer het later opnieuw.';
                        formMessage.style.color = 'red';
                    });
            }
        });
    });
</script>


      </footer>
      <a class="w-toplink pos_right active" href="#" title="Terug naar top" aria-label="Terug naar top" role="button"><i class="far fa-angle-up"></i></a>	<button id="w-header-show" class="w-header-show" aria-label="Menu"><span>Menu</span></button>
      <div class="w-header-overlay"></div>
      <script>
         // Store some global theme options used in JS
         if ( window.$us === undefined ) {
         	window.$us = {};
         }
         $us.canvasOptions = ( $us.canvasOptions || {} );
         $us.canvasOptions.disableEffectsWidth = 900;
         $us.canvasOptions.columnsStackingWidth = 600;
         $us.canvasOptions.backToTopDisplay = 100;
         $us.canvasOptions.scrollDuration = 1000;
         
         $us.langOptions = ( $us.langOptions || {} );
         $us.langOptions.magnificPopup = ( $us.langOptions.magnificPopup || {} );
         $us.langOptions.magnificPopup.tPrev = 'Vorige (Pijltoets links)';
         $us.langOptions.magnificPopup.tNext = 'Volgende (Pijltoets rechts)';
         $us.langOptions.magnificPopup.tCounter = '%curr% van %total%';
         
         $us.navOptions = ( $us.navOptions || {} );
         $us.navOptions.mobileWidth = 900;
         $us.navOptions.togglable = true;
         $us.ajaxLoadJs = true;
         $us.templateDirectoryUri = 'https://propixel.nl/wp-content/themes/Impreza';
         $us.responsiveBreakpoints = {"default":0,"laptops":1380,"tablets":1024,"mobiles":600};
      </script>
      <script id="us-header-settings">if ( window.$us === undefined ) window.$us = {};$us.headerSettings = {"default":{"options":{"custom_breakpoint":0,"breakpoint":"","orientation":"hor","sticky":true,"sticky_auto_hide":false,"scroll_breakpoint":"1px","transparent":1,"width":"300px","elm_align":"center","shadow":"thin","top_show":0,"top_height":"40px","top_sticky_height":"40px","top_fullwidth":0,"top_centering":0,"top_bg_color":"_header_top_bg","top_text_color":"_header_top_text","top_text_hover_color":"_header_top_text_hover","top_transparent_bg_color":"_header_top_transparent_bg","top_transparent_text_color":"_header_top_transparent_text","top_transparent_text_hover_color":"_header_top_transparent_text_hover","middle_height":"100px","middle_sticky_height":"80px","middle_fullwidth":0,"middle_centering":0,"elm_valign":"top","bg_img":"","bg_img_wrapper_start":"","bg_img_size":"cover","bg_img_repeat":"repeat","bg_img_position":"top left","bg_img_attachment":1,"bg_img_wrapper_end":"","middle_bg_color":"_header_middle_bg","middle_text_color":"_header_middle_text","middle_text_hover_color":"_header_middle_text_hover","middle_transparent_bg_color":"_header_transparent_bg","middle_transparent_text_color":"_header_middle_text","middle_transparent_text_hover_color":"_header_middle_text_hover","bottom_show":0,"bottom_height":"50px","bottom_sticky_height":"50px","bottom_fullwidth":0,"bottom_centering":0,"bottom_bg_color":"_header_middle_bg","bottom_text_color":"_header_middle_text","bottom_text_hover_color":"_header_middle_text_hover","bottom_transparent_bg_color":"_header_transparent_bg","bottom_transparent_text_color":"_header_transparent_text","bottom_transparent_text_hover_color":"_header_transparent_text_hover"},"layout":{"top_left":[],"top_center":[],"top_right":[],"middle_left":["image:1","menu:1"],"middle_center":[],"middle_right":["btn:2","btn:1"],"bottom_left":[],"bottom_center":[],"bottom_right":[],"hidden":[]}},"laptops":{"options":{"custom_breakpoint":0,"breakpoint":"1380px","orientation":"hor","sticky":true,"sticky_auto_hide":false,"scroll_breakpoint":"1px","transparent":0,"width":"300px","elm_align":"center","shadow":"thin","top_show":0,"top_height":"40px","top_sticky_height":"40px","top_fullwidth":0,"top_centering":0,"top_bg_color":"_header_top_bg","top_text_color":"_header_top_text","top_text_hover_color":"_header_top_text_hover","top_transparent_bg_color":"_header_top_transparent_bg","top_transparent_text_color":"_header_top_transparent_text","top_transparent_text_hover_color":"_header_top_transparent_text_hover","middle_height":"100px","middle_sticky_height":"80px","middle_fullwidth":1,"middle_centering":0,"elm_valign":"top","bg_img":"","bg_img_wrapper_start":"","bg_img_size":"cover","bg_img_repeat":"repeat","bg_img_position":"top left","bg_img_attachment":1,"bg_img_wrapper_end":"","middle_bg_color":"_header_middle_bg","middle_text_color":"_header_middle_text","middle_text_hover_color":"_header_middle_text_hover","middle_transparent_bg_color":"_header_transparent_bg","middle_transparent_text_color":"_header_transparent_text","middle_transparent_text_hover_color":"_header_transparent_text_hover","bottom_show":0,"bottom_height":"50px","bottom_sticky_height":"50px","bottom_fullwidth":0,"bottom_centering":0,"bottom_bg_color":"_header_middle_bg","bottom_text_color":"_header_middle_text","bottom_text_hover_color":"_header_middle_text_hover","bottom_transparent_bg_color":"_header_transparent_bg","bottom_transparent_text_color":"_header_transparent_text","bottom_transparent_text_hover_color":"_header_transparent_text_hover"},"layout":{"top_left":[],"top_center":[],"top_right":[],"middle_left":["image:1","menu:1"],"middle_center":[],"middle_right":["btn:2","btn:1"],"bottom_left":[],"bottom_center":[],"bottom_right":[],"hidden":[]}},"tablets":{"options":{"custom_breakpoint":0,"breakpoint":"1024px","orientation":"hor","sticky":true,"sticky_auto_hide":false,"scroll_breakpoint":"1px","transparent":0,"width":"300px","elm_align":"center","shadow":"thin","top_show":0,"top_height":"40px","top_sticky_height":"40px","top_fullwidth":0,"top_centering":0,"top_bg_color":"_header_top_bg","top_text_color":"_header_top_text","top_text_hover_color":"_header_top_text_hover","top_transparent_bg_color":"_header_top_transparent_bg","top_transparent_text_color":"_header_top_transparent_text","top_transparent_text_hover_color":"_header_top_transparent_text_hover","middle_height":"100px","middle_sticky_height":"80px","middle_fullwidth":1,"middle_centering":0,"elm_valign":"top","bg_img":"","bg_img_wrapper_start":"","bg_img_size":"cover","bg_img_repeat":"repeat","bg_img_position":"top left","bg_img_attachment":1,"bg_img_wrapper_end":"","middle_bg_color":"_header_middle_bg","middle_text_color":"_header_middle_text","middle_text_hover_color":"_header_middle_text_hover","middle_transparent_bg_color":"_header_transparent_bg","middle_transparent_text_color":"_header_transparent_text","middle_transparent_text_hover_color":"_header_transparent_text_hover","bottom_show":0,"bottom_height":"50px","bottom_sticky_height":"50px","bottom_fullwidth":0,"bottom_centering":0,"bottom_bg_color":"_header_middle_bg","bottom_text_color":"_header_middle_text","bottom_text_hover_color":"_header_middle_text_hover","bottom_transparent_bg_color":"_header_transparent_bg","bottom_transparent_text_color":"_header_transparent_text","bottom_transparent_text_hover_color":"_header_transparent_text_hover"},"layout":{"top_left":[],"top_center":[],"top_right":[],"middle_left":["image:1"],"middle_center":[],"middle_right":["menu:1"],"bottom_left":[],"bottom_center":[],"bottom_right":[],"hidden":["btn:2","btn:1"]}},"mobiles":{"options":{"custom_breakpoint":0,"breakpoint":"600px","orientation":"hor","sticky":true,"sticky_auto_hide":false,"scroll_breakpoint":"1px","transparent":0,"width":"300px","elm_align":"center","shadow":"thin","top_show":0,"top_height":"40px","top_sticky_height":"40px","top_fullwidth":0,"top_centering":0,"top_bg_color":"_header_top_bg","top_text_color":"_header_top_text","top_text_hover_color":"_header_top_text_hover","top_transparent_bg_color":"_header_top_transparent_bg","top_transparent_text_color":"_header_top_transparent_text","top_transparent_text_hover_color":"_header_top_transparent_text_hover","middle_height":"70px","middle_sticky_height":"70px","middle_fullwidth":1,"middle_centering":0,"elm_valign":"top","bg_img":"","bg_img_wrapper_start":"","bg_img_size":"cover","bg_img_repeat":"repeat","bg_img_position":"top left","bg_img_attachment":1,"bg_img_wrapper_end":"","middle_bg_color":"_header_middle_bg","middle_text_color":"_header_middle_text","middle_text_hover_color":"_header_middle_text_hover","middle_transparent_bg_color":"_header_transparent_bg","middle_transparent_text_color":"_header_transparent_text","middle_transparent_text_hover_color":"_header_transparent_text_hover","bottom_show":0,"bottom_height":"50px","bottom_sticky_height":"50px","bottom_fullwidth":0,"bottom_centering":0,"bottom_bg_color":"_header_middle_bg","bottom_text_color":"_header_middle_text","bottom_text_hover_color":"_header_middle_text_hover","bottom_transparent_bg_color":"_header_transparent_bg","bottom_transparent_text_color":"_header_transparent_text","bottom_transparent_text_hover_color":"_header_transparent_text_hover"},"layout":{"top_left":[],"top_center":[],"top_right":[],"middle_left":["image:1"],"middle_center":[],"middle_right":["menu:1"],"bottom_left":[],"bottom_center":[],"bottom_right":[],"hidden":["btn:2","btn:1"]}},"header_id":13};</script>
      <script src="https://code.jquery.com/jquery-3.7.1.js" integrity="sha256-eKhayi8LEQwp4NKxN+CfCh+3qOVUtJn3QNZ0TciWLP4=" crossorigin="anonymous"></script>

      <script src="/assets/js/script.js?v=1" id="us-core-js"></script>
   </body>
</html>
